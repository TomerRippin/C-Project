#ifndef ASSEMBLER_H
#define ASSEMBLER_H

#include "files_utils.h"
#include "pre_assembler.h"
#include "first_pass.h"
#include "second_pass.h"

int main(int argc, char *argv[]);

#endif /* ASSEMBLER_H */